#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(int argc, char *argv[]) {
    // argv[0] = program name, argv[1] = command, argv[2] = argument
    if (argc != 3) {
        printf("Incorrect number of arguments\n");
        return 1;
    }

    pid_t pid = fork();

    if (pid < 0) {
        // failed
        perror("Fork failed");
        return 1;
    } else if (pid == 0) {
        // Child process
        execlp(argv[1], argv[1], argv[2], (char *)NULL);
        
        perror("Command execution failed");
        exit(1);
    } else {
        // Parent process
        wait(NULL);
        printf("Command successfully completed\n");
    }

    return 0;
}
