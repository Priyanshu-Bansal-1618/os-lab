#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
void use_execvp() {
	printf("Using execlp command:\n");
	char* args[] = {"ls", "-l", (char *)NULL};
	execvp("ls", args);
}
int main()
{
	use_execvp();
}
