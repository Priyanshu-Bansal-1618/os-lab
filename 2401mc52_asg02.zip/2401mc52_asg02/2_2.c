#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
void use_execlp() {
	printf("Using execlp command:\n");
	execlp("ls", "ls", "-l", (char *)NULL);
}
int main()
{
	use_execlp();
}
