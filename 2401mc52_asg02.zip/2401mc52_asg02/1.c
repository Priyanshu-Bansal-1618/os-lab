// The program forks a child process, After it exits, the parent reaps the dead child before exiting.

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>

int main()
{
	pid_t pid = fork();
	if(pid < 0) {
      		perror("fork fail");
      		exit(1);
    	}
	else if(pid == 0) {
		printf("I am a child. My PID is %d\n", getpid());
	}	
	else {
		wait(NULL);
		printf("I am a parent. My PID is %d\n", getpid());
	}
	return 0;
}