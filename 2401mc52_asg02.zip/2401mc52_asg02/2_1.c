#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
void use_execl() {
	printf("Using execl command:\n");
	execl("/bin/ls", "ls", "-l", (char *)NULL);
}
int main()
{
	use_execl();
}
